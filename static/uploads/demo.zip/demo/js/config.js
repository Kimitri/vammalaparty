var Config = {
	display: {
		framerate: 30,
		fillViewport: true,
		canvasSize: {w: 600, h: 400}
	},
	emtIds: {
		audio: "bgMusic",
		canvas: "canvas"
	}
}; 
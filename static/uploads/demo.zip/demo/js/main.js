var Demo = {
	
	canvasEmt: null,
	audioEmt: null,
	canvasSize: null,
	canvasPosition: null,
	canvasContext: null,
	
	drawFn: function(){FX.boxes(Demo);}, // The draw function to be passed to the update cycle
	
	updateTimer: null,

	init: function(){
		this.canvasEmt = document.getElementById(Config.emtIds.canvas);
		this.audioEmt = document.getElementById(Config.emtIds.audio);
		
		this.initCanvas();
		this.audioEmt.addEventListener("loadeddata", function(){Demo.start();}, true);
		this.audioEmt.addEventListener("ended", function(){Demo.stop();}, true);
	},
	
	initCanvas: function(){
		if(Config.display.fillViewport){
			this.canvasSize = {width: $(window).width() - 5, height: $(window).height() - 5};
			this.canvasPosition = {x: 0, y: 0};
		}
		else{
			this.canvasSize = {width: Config.display.canvasSize.width, height: Config.display.canvasSize.height};
			this.canvasPosition = {x: $(window).innerwidth() / 2 - Config.display.canvasSize.width / 2, y: $(window).height() / 2 - Config.display.canvasSize.height / 2};
		}
		
		$(this.canvasEmt).css({
			width: Demo.canvasSize.width + "px",
			height: Demo.canvasSize.height + "px",
			left: Demo.canvasPosition.x + "px",
			top: Demo.canvasPosition.y + "px"
		});
		
		this.canvasContext = this.canvasEmt.getContext("2d");
	},
	
	start: function(){
		this.audioEmt.play();
		
		// Start draw cycle
		this.update();
	},
	
	update: function(){
		Demo.drawFn();
		Demo.updateTimer = setTimeout(function(){Demo.update();}, 1000 / Config.display.framerate);
	},
	
	stop: function(){
		clearTimeout(this.updateTimer);
		window.location.href = "finished.html";
	}
};

$(document).ready(function(){
	Demo.init();
});
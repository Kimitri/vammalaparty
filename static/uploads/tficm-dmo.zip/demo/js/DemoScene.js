(function(){
	var DemoScene = function(demoInstance){
		this.demo = demoInstance;
		this.scene = null;
		this.camera = null;
		this.endBar = 0;
		this.startTime = 0;
	};
	
	DemoScene.prototype.update = function(){};
	
	window.DemoScene = DemoScene;
})();
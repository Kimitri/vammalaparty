var demo = new Demo();
demo.timing.bpm = 130;

demo.init('viewport', 'ogg/Anal-ogia.ogg');

(function($){
	$(window).load(function(){
		demo.start();
		demo.endHandler = function(demoInstance){
			window.location.href = 'end.html';
		}
	});
})(jQuery);